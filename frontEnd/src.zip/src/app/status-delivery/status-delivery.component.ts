import { BillingService } from './../billing.service';
import { Order } from './../order';
import { Component, OnInit } from '@angular/core';
import { equal } from 'assert';

@Component({
  selector: 'app-status-delivery',
  templateUrl: './status-delivery.component.html',
  styleUrls: ['./status-delivery.component.css']
})
export class StatusDeliveryComponent implements OnInit {

  
  Olists: Order[];
  user = sessionStorage.getItem('username');
  lastOrder: Order


  orderdemo : Order;

  constructor( private _billingService: BillingService ) { }

 
  percentage = 12;

  ngOnInit(): void {
    console.log(this.lastOrder);
    //this.getStatus();
  }

  getStatus(){
  console.log(this.user);
  this._billingService.getDelivaryStatus(this.user).subscribe((orderList) => this.Olists = orderList);

  let last = this.Olists.length - 1;
  this.lastOrder = this.Olists[last];

  if (this.lastOrder.orderStatus == "confirmed")
  {
    this.percentage = 6;
  }
  if (this.lastOrder.orderStatus == "shipped")
  {
    this.percentage = 50;
  }
  if (this.lastOrder.orderStatus == "delivered")
  {
    this.percentage = 100;
  }



  }



}
