export class ProductFeedback{
    feedbackId: number
    feedbackSubject: String
    feedbackMessage: String
    productId: number
    userId: number
}