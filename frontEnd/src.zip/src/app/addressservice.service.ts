import { UserAddress } from './address';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AddressserviceService {

  private getaddressesURL = 'http://localhost:5000//CapStore/Billing/addresses/3';
  private newAddressURL='http://localhost:5000//CapStore/Billing/address/create/3';
  private deleteAddressURL='http://localhost:5000//CapStore/Billing/address/delete/3/';

  constructor(private http:HttpClient) { 

  }
  getAddresses():Observable<UserAddress[]>{
      return this.http.get<UserAddress[]>(`${this.getaddressesURL}`);
  }

  saveNewAddress(address:UserAddress){
      return this.http.post(`${this.newAddressURL}`,address);
  }
  deleteAddress(addressId:number){
      return this.http.delete(`${this.deleteAddressURL}`+addressId);
  }
}
