import { BillingService } from './../billing.service';
import { Order } from './../order';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  cashOnDeliver:boolean;
  debit:boolean;
  credit:boolean=true;
  netBanking:boolean;
  type: String = 'COD';

  constructor(private formBuilder:FormBuilder, private _router: Router, private _billingService: BillingService) { }

  couponCode: string;

  model: Order;
  discount: number;
  order = new Order();

  ch = false;

  ngOnInit() {
    this.model = this._billingService.getOrder();
  }

  apply() {
    this._billingService.apply(this.model, this.couponCode).subscribe(
      res=>{
        if(res) {
          this.ch=true;
          this.order=res;
          this.discount = -(this.model.orderAmount - this.order.orderAmount);
          alert("Coupon Applied Successfully!");
        }
        else {
          alert("Invalid Coupon!!");
        }
      },
      err=> {
        alert("Invalid Coupon!!");
      })
  }



creditForm=this.formBuilder.group({
    name:["",[Validators.required,Validators.pattern('[a-zA-Z ]*')]],
    cardNumber:["",[Validators.required,Validators.pattern('\\d{16}')]],
    month:["",[Validators.required,Validators.pattern("^(1[012]|0?[1-9])$")]],
    year:["",[Validators.required,Validators.pattern('2[0-9]\\d{2}')]],
    cvv:["",[Validators.required,Validators.pattern('\\d{3}')]]
});

debitForm=this.formBuilder.group({
  name:["",[Validators.required,Validators.pattern('[a-zA-Z ]*')]],
  cardNumber:["",[Validators.required,Validators.pattern('\\d{16}')]],
  month:["",[Validators.required,Validators.pattern("^(1[012]|0?[1-9])$")]],
  year:["",[Validators.required,Validators.pattern('2[0-9]\\d{2}')]],
  cvv:["",[Validators.required,Validators.pattern('\\d{3}')]]
});

  setCashOnDelivery(){
    this.cashOnDeliver=true;
    this.debit=false;
    this.credit=false;
    this.netBanking=false;
    this.type = 'COD';
  }
  setDebit(){
    this.cashOnDeliver=false;
    this.debit=true;
    this.credit=false;
    this.netBanking=false;
    this.type = 'Debit Card';
  }
  setCredit(){
    this.cashOnDeliver=false;
    this.debit=false;
    this.credit=true;
    this.netBanking=false;
    this.type = 'Credit Card';
  }
  setNetBanking(){
    this.cashOnDeliver=false;
    this.debit=false;
    this.credit=false;
    this.netBanking=true;
    this.type = 'Net Banking';
  }

  confirmPayment() {
    this._router.navigate(['invoice']);
  }
}
