import { Order } from './order';
import { Transaction } from './transaction';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BillingService {

  private transaction: Transaction;
  private model: Order;
  private baseURL = 'http://localhost:5000/CapStore/Billing';
  private headers = new HttpHeaders ({'Content-Type': 'application/json'});
  private options = {headers: this.headers};
  constructor(private _http: HttpClient ) { }

  downloadInvoice (orderId, customerId) {
    return this._http.get(this.baseURL + '/download/' + orderId + '/' + customerId, {
      responseType: 'arraybuffer'
    });
  }

  apply(order:Order, code: string) {
    console.log("checking");
    return this._http.put<Order>(this.baseURL + '/applyCoupon/' + code, order, this.options);
  }

  public getOrder(): Order {
      return this.model;
  }

  public setOrder(newModel: Order) {
      this.model = newModel;
  }

  public getDelivaryStatus(userId) {
    return this._http.get(this.baseURL + "/getDelivaryStatus/" + userId);
  }
}
