export class UserAddress{
    addressId:number
    address_line1:string
    address_line2:string
    district:string
    state:string
    landmark:string
    pinCode:number
    userId:number
}