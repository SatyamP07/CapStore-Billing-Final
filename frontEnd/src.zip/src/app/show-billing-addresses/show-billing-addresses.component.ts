import { Router } from '@angular/router';
import { UserAddress } from './../address';
import { AddressserviceService } from './../addressservice.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-billing-addresses',
  templateUrl: './show-billing-addresses.component.html',
  styleUrls: ['./show-billing-addresses.component.css']
})
export class ShowBillingAddressesComponent implements OnInit {

  addresses:UserAddress[];
  errorMessage:any;
  showComponent:boolean;
  addressId: number;
  constructor(private addressService:AddressserviceService,private _router:Router) {
   }

  ngOnInit(): void {
    this.addressService.getAddresses().subscribe(
      data=>{
        console.log(data);
        this.addresses=data;
      }
    );
  }

  setCureentAddress(event :any)
  {
      this.addressId=event.target.value;
      this.errorMessage="";
  } 
    
  currentAddress(){
    if(this.addressId==undefined){
      this.errorMessage="select the address";
    }
    else{
      sessionStorage.setItem('addressId', this.addressId.toString());
      this._router.navigate(['payment']);
    }
      
  }
  
  deleteAddress(addressId:number) {
    console.log("deleted");
      this.addressService.deleteAddress(addressId).subscribe(
        data=>{
            console.log(data);
            console.log("deleted");
            console.log(addressId);
        }
      );
     window.location.reload();
  }

}
