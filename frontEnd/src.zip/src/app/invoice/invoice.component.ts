import { BillingService } from '../billing.service';
import { Component, OnInit } from '@angular/core';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-invoiceorder',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
  private fileName: string;
  private orderId = 10;
  private customerId = 3;
  constructor(private _billingService: BillingService) { }

  ngOnInit() {
    this.fileName = 'Invoice-Order-Id-10.pdf';
  }

  downloadInvoice() {
    this._billingService.downloadInvoice(this.orderId, this.customerId).subscribe( data => {
      saveAs(new Blob([data], {type: 'application/pdf'}), this.fileName);
    });
  }
}
