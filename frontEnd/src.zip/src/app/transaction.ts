export class Transaction{
    transactionId: number;
    transactionDate: Date;
    transactionMoney: number;
    transactionMethod: string;
    transactionStatus: string;
}